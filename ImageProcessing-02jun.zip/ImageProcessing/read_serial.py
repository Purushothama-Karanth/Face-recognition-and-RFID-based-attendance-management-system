import MySQLdb
import serial
import time
import sys

import cv2

from datetime import date
today = date.today()

com_port = 'COM4'
db_host = 'localhost'
db_user = 'root'
db_password = ''
db = 'attendance_management_db'

try:
    db = MySQLdb.connect(db_host, db_user, db_password, db, autocommit=True)
except Exception as ex:
    print(ex)
    sys.exit(0)

faceDetect = cv2.CascadeClassifier(r'''haarcascade_frontalface_alt2.xml''')

def detector():
    cam = cv2.VideoCapture(0);
    rec = cv2.face.LBPHFaceRecognizer_create();
    rec.read("recognizer/trainingData.yml");
    id = 0
    faceid = 0
    fontface = cv2.FONT_HERSHEY_SIMPLEX
    fontsize = 1
    fontcolor = (0,511,1)
    count=0
    person1Count,person2Count,Person3Count=0, 0, 0
    c=0
    detectedPersonsList=[]
    detectedPerson=''
    while 1:
        ret,img = cam.read();
        image=img
        gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        faces = faceDetect.detectMultiScale(gray,1.3,5);
        for(x,y,w,h) in faces:
            cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,180),2)
            id,conf = rec.predict(gray[y:y+h,x:x+w])
            if(id==1 and conf<50):
                id="Person1"
                person1Count=person1Count+1
                if person1Count > 30:
                    detectedPersonsList.append(id)
                    # person1Count=0
                    faceid = 1
                    cam.release()
                    cv2.destroyAllWindows()
                    return faceid

            elif(id==2 and conf<50):
                id="Person2"
                person2Count=person2Count + 1
                if person2Count > 30:
                    detectedPersonsList.append(id)
                    faceid = 2
                    cam.release()
                    cv2.destroyAllWindows()
                    return faceid
            elif(id==3 and conf<50):
                id="Person3"
                Person3Count = Person3Count + 1
                if Person3Count > 30:
                    detectedPersonsList.append(id)
                    faceid = 3
                    cam.release()
                    cv2.destroyAllWindows()
                    return faceid
            else:
                id="Stranger"

            if id in detectedPersonsList:
                cv2.putText(img,'Not Found',(x,y+h+25),fontface,fontsize,fontcolor,2)
            else:
                cv2.putText(img,str(id),(x,y+h+25),fontface,fontsize,fontcolor,2)

        cv2.imshow("Face",img);

        if(cv2.waitKey(1)==ord('q')):
            break;
    cam.release()
    cv2.destroyAllWindows()

ser = serial.Serial(port=com_port, baudrate=9600)

time.sleep(5)
# print(ser.name)

while 1:
    ser.flush()
    time.sleep(5)
    msg = ser.read(ser.inWaiting()).decode('utf-8').strip('\\n\\r')
    # msg = 'A1'
    # print(msg)

    msg = msg.strip()

    if '' != msg:
        data_array = msg.split(' ')

        print(data_array[0])
        input=data_array[0]

        if len(input) ==2:
            subject_id = 1 if input[0]=='A' else 2
            student_id = input[1]
            
            
            if int(student_id) is not 0:
                face_id = detector()
                print(face_id)
                if int(student_id) == int(face_id):
                    cursor = db.cursor()

                    sql = "INSERT INTO attendancemanagementapp_attendance(subject_id, student_id, status, date, time)"\
                        " VALUES(%s, %s, %s, %s, NOW())"

                    cursor.execute(sql, [subject_id, student_id, '1',today.strftime("%Y-%m-%d")])

                    cursor.close()

                    print('Database updated...')
                else:
                    print("Face Not Matched")
            else:
                print("Unauthorized Student")
