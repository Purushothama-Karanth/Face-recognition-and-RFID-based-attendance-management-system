from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage


def sendMail():

    strFrom = 'From_Email_ID'
    strTo = 'owner_gmail_goes_here'

    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = 'Intruder Detection System'
    msgRoot['From'] = strFrom
    msgRoot['To'] = strTo
    msgRoot.preamble = 'This is a multi-part message in MIME format.'

    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)

    msgText = MIMEText('Image')
    msgAlternative.attach(msgText)

    msgText = MIMEText('System Found an Intruder. Please take appropriate Action Soon<br><img src="cid:image1"><br>', 'html')
    msgAlternative.attach(msgText)


    fp = open('unknownperson.jpg', 'rb')
    msgImage = MIMEImage(fp.read())
    fp.close()

    msgImage.add_header('Content-ID', '<image1>')
    msgRoot.attach(msgImage)

    import smtplib
    smtp = smtplib.SMTP('smtp.gmail.com', 587)
    smtp.connect('smtp.gmail.com',587)
    smtp.ehlo()
    smtp.starttls()
    smtp.ehlo()
    smtp.login(strFrom, 'Password')
    smtp.sendmail(strFrom, strTo, msgRoot.as_string())
    smtp.quit()

