from django.db import models

# Create your models here.
class students(models.Model):
    name = models.CharField(max_length=30)
    stdid = models.CharField(max_length=10)
    email = models.CharField(max_length=30)
    phone = models.CharField(max_length=15)
    # password = models.CharField(max_length=50)

class subjects(models.Model):
    subject = models.CharField(max_length=50)

class attendance(models.Model):
    subject = models.ForeignKey('subjects',on_delete=models.CASCADE)
    student = models.ForeignKey('students',on_delete=models.CASCADE)
    status = models.IntegerField()
    date = models.CharField(max_length=10)
    time = models.CharField(max_length=10)
