from django.shortcuts import render, redirect

from django.views.decorators.csrf import csrf_exempt

from AttendanceManagementApp.models import *

# Create your views here.

def index(request):
    return render(request,'index.html')

def adminLogin(request):
    return render(request,'admin/login.html')

def adminPanel(request):
    data = subjects.objects.all()
    res = {
        "subjects": data
    }
    return render(request,'admin/home.html',res)

def doAdminLogin(request):
    username = request.GET['username']
    password = request.GET['password']

    if ((username == "admin") and (password == "123456")):
        return redirect('/panel/')
    else:
        return redirect('/admin/')

def getResult(request):
    subject = request.GET['subject']
    date = request.GET['date']
    data = attendance.objects.filter(subject_id=subject,date=date).values('id','student__name','student__stdid','status','date','time')
    # subject_name = subjects.objects.filter(id=subject).values('subject').order_by('if')
    res = {
        "datas": data
        # "subname": subject_name
    }
    return render(request,'admin/result.html',res)
